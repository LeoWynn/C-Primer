//
//  AboutViewController.h
//  iPREditor
//
//  Created by admin on 3/11/16.
//  Copyright © 2016 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UITableViewController



@property (strong, nonatomic) IBOutlet UITableViewCell *icon;

@property (strong, nonatomic) IBOutlet UITableViewCell *software;

@property (strong, nonatomic) IBOutlet UITableViewCell *version;
@property (strong, nonatomic) IBOutlet UITableViewCell *company;
@end
