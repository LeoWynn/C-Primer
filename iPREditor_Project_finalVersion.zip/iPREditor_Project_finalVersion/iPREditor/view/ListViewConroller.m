//
//  ListViewConroller.m
//  iPREditor
//
//  Created by admin on 11/12/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "ListViewConroller.h"
#import "PlistTool.h"
#import "AppDelegate.h"

@implementation ListViewConroller

PlistTool* tool;
BOOL isEdit;
BOOL isModify;
int currentModifyIndex;
NSMutableArray* origin;
AppDelegate* delegate;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    tool = [PlistTool instance];
    isEdit = NO;
    isModify = NO;
    currentModifyIndex = -1;
    
    origin = [[self.keyValue componentsSeparatedByString:@" "] mutableCopy];
    
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
    
    delegate = [UIApplication sharedApplication].delegate;
}

- (void)editClicked: (id)sender {
    
    if ([[sender title] isEqualToString:@"Edit"]) {
        isEdit = YES;
    
        for (int i = 0; i < origin.count; i++) {
            NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
            [self.tableView cellForRowAtIndexPath:path].textLabel.textColor = [UIColor blackColor];
        }
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addClicked:)];
        self.navigationItem.rightBarButtonItem.title = @"Done";
        
    }
    //点击的是Done
    else {
        isEdit = NO;
        
        NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
        
        id node = self.dictionary;
        id lastNode = node;
        //类型是String时
        if ([self.type isEqualToString:STRING_STR]) {
            
            NSString* result = @"";
            for (NSString* tem in origin) {
                
                result = [NSString stringWithFormat:@"%@ %@",result,tem];
            }
            result = [result stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            //与初始值不相等时
            if ([result isEqualToString:self.keyValue] == NO) {
                
                //设置保存标志位
                delegate.isChanged = YES;
                
                for (int i = 0; i < keys.count - 1; i++) {
                    
                    node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                    
                    //如果key不存在，需要创建
                    if (!node) {
                        NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                        [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                        node = tem;
                    }
                    lastNode = node;
                }
                [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
                self.keyValue = result;
                [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
            }
        }
        //类型是array
        else {
            
            //与初始值不相等
            if ([origin isEqualToArray:[self.keyValue componentsSeparatedByString:@" "]] == NO) {
                
                //设置保存标志位
                delegate.isChanged = YES;
                
                for (int i = 0; i < keys.count - 1; i++) {
                    
                    node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                    
                    //如果key不存在，需要创建
                    if (!node) {
                        NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                        [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                        node = tem;
                    }
                    lastNode = node;
                }
                [tool setValue:origin forKey:[keys lastObject] inDictionary:node recursion:NO];
                
                NSString* result = @"";
                for (NSString* tem in origin) {
                    
                    result = [NSString stringWithFormat:@"%@ %@",result,tem];
                }
                result = [result stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                self.keyValue = result;
                [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
            }
            
        }
        
        for (int i = 0; i < origin.count; i++) {
            NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
            [self.tableView cellForRowAtIndexPath:path].textLabel.textColor = [UIColor grayColor];
        }
        self.navigationItem.leftBarButtonItem = NULL;
        self.navigationItem.rightBarButtonItem.title = @"Edit";
        
    }
}

- (void)addClicked: (id) sender {
    
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Add new value" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        UITextField* value = alertController.textFields.firstObject;
        
        [origin insertObject:value.text atIndex:origin.count];
        [self.tableView beginUpdates];
        [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:origin.count - 1 inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView endUpdates];
        
        
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField){
        textField.placeholder = @"input new value";
    }];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}

- (NSArray*)getSelectedValue {
    
    NSMutableArray* result = nil;
   
    return result;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"setting_time_cellId";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        
    }
    cell.textLabel.textColor = [UIColor blackColor];
    if (isEdit == NO) {
        cell.textLabel.textColor = [UIColor grayColor];
    }

    cell.textLabel.text = origin[indexPath.row];
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return origin.count;
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    return self.keyLabel;
}

//去掉分区标题大写
- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    if (section == 0) {
        
        [header.textLabel setText:self.keyLabel];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (isEdit) {
        isModify = YES;
        currentModifyIndex = (int)indexPath.row;
        
        UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Modify value" message:@"" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction* okAction = [UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            UITextField* value = alertController.textFields.firstObject;
            
            origin[currentModifyIndex] = value.text;
            
            [self.tableView reloadData];
            
            
        }];
        [alertController addAction:cancelAction];
        [alertController addAction:okAction];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField){
            textField.text = [origin objectAtIndex:indexPath.row];
        }];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {

    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if (isEdit) {
            [origin removeObjectAtIndex:indexPath.row];
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
        }
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
    }
}

@end
