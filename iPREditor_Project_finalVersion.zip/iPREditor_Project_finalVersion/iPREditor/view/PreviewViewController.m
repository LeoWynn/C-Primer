//
//  PreviewController.m
//  iPREditor
//
//  Created by admin on 11/4/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "PreviewViewController.h"
#import "FolderViewController.h"
#import "PlistTool.h"
#import "PreviewSearchView.h"
#import "AppDelegate.h"
#import "FXPlistTool.h"


# define CELL_SIZE 120
# define MARGIN 20
# define STATUS_SIZE 20


#ifndef NSFoundationVersionNumber_iOS_6_1
#define NSFoundationVersionNumber_iOS_6_1 993.0
#endif

@interface  PreviewViewController ()
{
    NSString* result;
    UISearchBar *_searchBar;
    CGPoint _startCenter;
    UIScrollView *_scrollView;
    UIView *_contentView;
    PreviewSearchView* _textView;
}
@end

@implementation PreviewViewController
NSString * documentDirectory;
NSString* bundlePath;
PlistTool* plistTool;
NSMutableArray* data;
NSMutableDictionary* dic;
NSString* currentKey;
NSUInteger currentIndex;
BOOL showsHorizontalScrollIndicator;

NSString* plistPath;
NSString* temp;
AppDelegate* delegate;

CGFloat lastScale;
CGPoint point;
BOOL isAlertView;

NSMutableString *plistKey;
FXPlistTool *plistHandler;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    //找到Documents文件所在的路径
    
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    //取得第一个Documents文件夹的路径
    
    NSString *filePath = [path objectAtIndex:0];
    
    NSLog(@"%@", filePath);
    //把TestPlist文件加入
    
    NSString *plistPath = [filePath stringByAppendingPathComponent:@"test.plist"];
    
    //开始创建文件
    
    [fm createFileAtPath:plistPath contents:nil attributes:nil];
    
    //删除文件
    
    [fm removeItemAtPath:plistPath error:nil];
    
    //在写入数据之前，需要把要写入的数据先写入一个字典中，创建一个dictionary：
    
    //创建一个字典
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"zhangsan",@"1",@"lisi",@"2", nil];
    
    //把数据写入plist文件
    
    [dic writeToFile:plistPath atomically:YES];
    
    //读取plist中的数据，形式如下：
    
    //读取plist文件，首先需要把plist文件读取到字典中
    
    NSDictionary *dic2 = [NSDictionary dictionaryWithContentsOfFile:plistPath];
    
    //打印数据
    
    NSLog(@"key1 is %@",[dic2 valueForKey:@"1"]);
    
    NSLog(@"dic is %@",dic2);
    

    
    //把TestPlist文件加入
    
    NSString *plistPaths = [filePath stringByAppendingPathComponent:@"tests.plist"];
    
    //开始创建文件
    
    [fm createFileAtPath:plistPaths contents:nil attributes:nil];
    
    //创建一个数组
    
    NSArray *arr = [[NSArray alloc] initWithObjects:@"1",@"2",@"3",@"4", nil];
    
    //写入
    
    [arr writeToFile:plistPaths atomically:YES];
    
    //读取
    
    NSArray *arr1 = [NSArray arrayWithContentsOfFile:plistPaths];
    
    //打印
    
    NSLog(@"arr1is %@",arr1);

    
    
    self.navigationItem.title = [self.fullPath lastPathComponent];
    
    BOOL iOS7=NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1;
    
    CGRect tempFrame=[UIScreen mainScreen].bounds;
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, 44)];
    _searchBar.delegate = self;
    _searchBar.showsCancelButton = NO;
    _searchBar.placeholder = @"Search";

    for (UIView *view in _searchBar.subviews) {

        if ([view isKindOfClass:NSClassFromString(@"UISearchBarBackground")]) {
            [view removeFromSuperview];
            break;
        }

        if ([view isKindOfClass:NSClassFromString(@"UIView")] && view.subviews.count > 0) {
            [[view.subviews objectAtIndex:0] removeFromSuperview];
            break;
        }
    }
    

    _textView.keyboardType = UIKeyboardTypeASCIICapable;
    _searchBar.keyboardType = UIKeyboardTypeASCIICapable;
    
    self.automaticallyAdjustsScrollViewInsets = YES;
    
    _searchBar.layer.borderWidth = 1;
    _searchBar.layer.borderColor = [UIColor grayColor].CGColor;
    
    
    _searchBar.delegate=self;
    _searchBar.keyboardType=UIKeyboardTypeDefault;
    
    [_searchBar setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    CGFloat tabBarItemHeight = 0;
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            tabBarItemHeight = view.frame.size.height;
            break;
        }
    }
    
    

    if (!iOS7) {
        tempFrame.origin.y =0.0;
    }
    
    _textView = [[PreviewSearchView alloc] initWithFrame:CGRectMake(0, 60, tempFrame.size.width, tempFrame.size.height)];
    _textView.delegate=self;
    _textView.contentInset = UIEdgeInsetsMake(-50, 0, 230, 500);
    _textView.editable = NO;
    
    
    UIView *mainView =[[UIView alloc] initWithFrame:tempFrame];
    [mainView addSubview:_textView];
    [mainView addSubview:_searchBar];
    [self.view addSubview:mainView];
    
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    documentDirectory = [paths objectAtIndex:0];
    
     _textView.font = SYSTEM_SECONDARY_FONT_SIZE;
    [_searchBar becomeFirstResponder];
    

    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation]))
    {
        
        _searchBar.frame = CGRectMake(0, 30, tempFrame.size.width, 44);
        self.textView.frame = CGRectMake(0, 100, tempFrame.size.width, tempFrame.size.height-60- tabBarItemHeight);
       
    }
    else {
        
        _searchBar.frame = CGRectMake(0, 64, tempFrame.size.width, 44);
        self.textView.frame = CGRectMake(0, 108, tempFrame.size.width, tempFrame.size.height -108- tabBarItemHeight);
    }
    
    NSString* textString;
    _textView.text=textString;
    
    

    self.navigationItem.title = [self.fullPath lastPathComponent];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Close" style:UIBarButtonItemStylePlain target:self action:@selector(Close:)];
    
    UIBarButtonItem* rightBn= [[UIBarButtonItem alloc]initWithTitle:@"Edit" style:(UIBarButtonItemStylePlain) target:self action:@selector(beginEdit:) ];
    self.navigationItem.rightBarButtonItem=rightBn;

}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)
interfaceOrientation duration:(NSTimeInterval)duration
{
    CGFloat tabBarItemHeight = 0;
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            tabBarItemHeight = view.frame.size.height;
            break;
        }
    }
    CGRect tempFrame=[UIScreen mainScreen].bounds;
    if(UIInterfaceOrientationIsLandscape(interfaceOrientation))
    {
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            
            _searchBar.frame = CGRectMake(0, 64, tempFrame.size.width, 44);
            self.textView.frame = CGRectMake(0, 108, tempFrame.size.width+500, tempFrame.size.height -60-tabBarItemHeight);
            
        }
        else {
            
            _searchBar.frame = CGRectMake(0, 30, tempFrame.size.width, 44);
            self.textView.frame = CGRectMake(0, 80, tempFrame.size.width+200, tempFrame.size.height+20- tabBarItemHeight);
        }
        
    }
    else {
       
        _searchBar.frame = CGRectMake(0, 64, tempFrame.size.width, 44);
        self.textView.frame = CGRectMake(0, 108, tempFrame.size.width+500, tempFrame.size.height -60-tabBarItemHeight);
        
    }
}


- (void)Close: (UIBarButtonItem*)sender {
    
    if (delegate.isChanged) {
        
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"File Changed" message:@"What do you wanna do?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OverWrite",@"Discard change", nil];
        [alert show];
        isAlertView = YES;
    }
    else {
        [delegate.navi popViewControllerAnimated:YES];
    }
}

#pragma - UIAlertView
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if(isAlertView == YES){

        if (buttonIndex == 1) {
            

            [delegate.fileTool write:[NSString stringWithContentsOfFile:delegate.temFilePath encoding:NSUTF8StringEncoding error:nil] at:self.fullPath append:NO];
            delegate.isChanged = NO;
            
            plistPath = delegate.temFilePath;
            _textView.text = [NSString stringWithContentsOfFile:plistPath encoding:NSASCIIStringEncoding error:NULL];

            [delegate.navi popViewControllerAnimated:YES];
        }

        else if (buttonIndex == 2) {
            
            delegate.isChanged = NO;

            [delegate.navi popViewControllerAnimated:YES];
        }
    }
    else if(isAlertView == NO){
        
        if (buttonIndex == 0) {
            
            _textView.isRecover = YES;
            
            [_textView setText:temp];
            
            self.navigationItem.rightBarButtonItem.title=@"Edit";
            _textView.editable = NO;
        }
        if (buttonIndex == 1){
            
            self.navigationItem.rightBarButtonItem.title=@"Done";
            
        }
    }
}


-(void)beginEdit:(id)sender
{
    if ([[sender title] isEqualToString:@"Edit"]) {
        
        [_textView resignFirstResponder];
        _textView.editable=YES;
    
        self.navigationItem.rightBarButtonItem.title=@"Done";
        [_searchBar resignFirstResponder];
        
 
    }
    else{
        
        isAlertView = NO;
        
        //_textView.text = [NSString stringWithContentsOfFile:plistPath encoding:NSUTF8StringEncoding error:NULL];
        
        
        NSString* temPreivewFile = [NSTemporaryDirectory() stringByAppendingPathComponent:@"Preview.tem"];
        
        [delegate.fileTool write:_textView.text at:temPreivewFile append:NO];
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithContentsOfFile:temPreivewFile];
        
        if (dic != NULL) {
            
            [dic writeToFile:plistPath atomically:YES];
            
            NSLog(@"plistPath: %@", plistPath);
            
            //[delegate.fileTool write:_textView.text at:plistPath append:NO];
            
            _textView.text = [NSString stringWithContentsOfFile:plistPath encoding:NSUTF8StringEncoding error:NULL];
           
            NSLog(@"_textView.text: %@", _textView.text);
            
            _textView.editable = NO;
            
        }
        else
        {
            NSMutableArray* array = [NSMutableArray arrayWithContentsOfFile:temPreivewFile];
            
            if (array != NULL) {
                
                [delegate.fileTool write:_textView.text at:plistPath append:NO];
                
                _textView.text = [NSString stringWithContentsOfFile:plistPath encoding:NSUTF8StringEncoding error:NULL];
                
                //[self.textView reloadInputViews];
                
                _textView.editable = NO;
            }
            else {
               
                isAlertView = NO;
                UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"What has been edited can't meet the correct plist format" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Recover former content",@"Cancel", nil];
                [alert show];
            }
        }
        self.navigationItem.rightBarButtonItem.title=@"Edit";
    }
}


- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:NO];
    
    plistPath = delegate.temFilePath;
    _textView.text = [NSString stringWithContentsOfFile:plistPath encoding:NSASCIIStringEncoding error:NULL];
    
    CGRect tempFrame=[UIScreen mainScreen].bounds;
    
    CGFloat tabBarItemHeight = 0;
 
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
    
            tabBarItemHeight = view.frame.size.height;
            
            break;
        }
    }
   
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            
            _searchBar.frame = CGRectMake(0, 64, tempFrame.size.width, 44);
            self.textView.frame = CGRectMake(0, 108, tempFrame.size.width+500, tempFrame.size.height -60-tabBarItemHeight);
            
        }
        else {
            
            _searchBar.frame = CGRectMake(0, 30, tempFrame.size.width, 44);
            self.textView.frame = CGRectMake(0, 60, tempFrame.size.width+400, tempFrame.size.height - 25 - tabBarItemHeight);
        }        
//        
//        _searchBar.frame = CGRectMake(0, 30, tempFrame.size.width, 44);
//        self.textView.frame = CGRectMake(0, 60, tempFrame.size.width+400, tempFrame.size.height - 25 - tabBarItemHeight);
       
    }
    else {
        _searchBar.frame = CGRectMake(0, 64, tempFrame.size.width, 44);
        self.textView.frame = CGRectMake(0, 108, tempFrame.size.width+500, tempFrame.size.height - 60 - tabBarItemHeight);
    }
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - UITextViewDelegate

-(void)textViewDidEndEditing:(UITextView *)textView{
    
    //[self.textView reloadInputViews];
    
   // [self.textView reloadInputViews];
    //[self.view addSubview:_textView];
 
    NSString* after_trim = [_textView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    textView.text=after_trim;
    
    if ([textView.text isEqualToString:temp] == NO){
       
        delegate.isChanged=YES;
    }
    else{
       
        delegate.isChanged=NO;
    }
    
}


-(void)textViewDidBeginEditing:(UITextView *)textView{
    
    temp=[_textView.text mutableCopy];
    
    [_searchBar resignFirstResponder];
    
}


#pragma mark - UISearchBarDelegate


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (!searchText || [searchText isEqualToString:@""])
    {
        [_textView resetSearch];
        return;
    }
    [_textView scrollToString:searchText searchOptions:NSRegularExpressionCaseInsensitive back:NO];
    
    UITapGestureRecognizer *tapGestureRecognizer=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ClickHideSearchBoard:)];
    [_textView addGestureRecognizer:tapGestureRecognizer];
}

- (void)ClickHideSearchBoard:(UITapGestureRecognizer *)gesture {
    [_textView resignFirstResponder];
    [_searchBar resignFirstResponder];
}

-(void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{

    UIToolbar * topView = [[UIToolbar alloc]
                           initWithFrame:CGRectMake(0, 0, 320, 50)];

    [topView setBarStyle:UIBarStyleDefault];

    UIBarButtonItem* myBn = [[UIBarButtonItem alloc]
                             initWithTitle:@"Last"
                             style:UIBarButtonItemStylePlain
                             target:self action:@selector(last)];
    
    NSDictionary* attribute = @{NSFontAttributeName:[UIFont fontWithName:@"Heiti SC" size:23]};
    [myBn setTitleTextAttributes:attribute forState:UIControlStateNormal];

    
    UIBarButtonItem* spaceBn = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];

    UIBarButtonItem* doneBn = [[UIBarButtonItem alloc]
                               initWithTitle:@"Next"
                               style:UIBarButtonItemStyleDone
                               target:self action:@selector(next)];
    [doneBn setTitleTextAttributes:attribute forState:UIControlStateNormal];

    NSArray * buttonsArray = [NSArray arrayWithObjects
                              :myBn,spaceBn,doneBn,nil];

    [topView setItems:buttonsArray];

    [searchBar setInputAccessoryView:topView];
    UITapGestureRecognizer *tapGestureRecognizer=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ClickHideBoard3:)];
    [_textView addGestureRecognizer:tapGestureRecognizer];
}


- (void)ClickHideBoard3:(UITapGestureRecognizer *)gesture {
    

    [_searchBar resignFirstResponder];
}

-(void) next
{
    [_textView scrollToString:_searchBar.text searchOptions:NSRegularExpressionCaseInsensitive back:NO];
}

-(void) last
{
   
    [_textView scrollToString:_searchBar.text searchOptions:NSRegularExpressionCaseInsensitive back:YES];
}


- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    

    if (_textView.selectedTextRange) {
        
        [self performSelector:@selector(textViewDidBeginEditing:) withObject:_textView afterDelay:0.1f];
    }
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [_textView scrollToString:searchBar.text searchOptions:NSRegularExpressionCaseInsensitive back:NO];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    searchBar.text = nil;
    [_textView resetSearch];
    
}

@end
