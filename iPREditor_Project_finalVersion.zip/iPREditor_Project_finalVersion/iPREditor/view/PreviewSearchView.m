//
//  PreviewViewController.m
//  iPREditor
//
//  Created by leslie on 15/11/20.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import "PreviewSearchView.h"
#import <QuartzCore/QuartzCore.h>


#ifndef NSFoundationVersionNumber_iOS_6_0
#define NSFoundationVersionNumber_iOS_6_0 993.0
#endif

#ifndef NSFoundationVersionNumber_iOS_6_1
#define NSFoundationVersionNumber_iOS_6_1 993.0
#endif


#define UIDocumentViewTag 181337


@interface PreviewSearchView ()
{

    NSMutableDictionary *_highlightsByRange;
    NSMutableArray *_primaryHighlights;
    NSMutableOrderedSet *_secondaryHighlights;
    

    NSRegularExpression *_regex;
    NSTimer *_autoRefreshTimer;
    NSRange _searchRange;
    NSUInteger _scanIndex;
    NSUInteger _lastScanIndex;
    NSRange _currentMatchRange;
    
    BOOL _performedNewScroll;
    BOOL _shouldUpdateScanIndex;
    

    BOOL _hasAppliediOS7Bugfix;

    
}
@end


static BOOL _highlightingSupported;

@implementation PreviewSearchView

#pragma mark - Synthesized properties

@synthesize primaryHighlightColor = _primaryHighlightColor;
@synthesize secondaryHighlightColor = _secondaryHighlightColor;
@synthesize highlightCornerRadius = _highlightCornerRadius;
@synthesize highlightSearchResults = _highlightSearchResults;
@synthesize maxHighlightedMatches = _maxHighlightedMatches;
@synthesize scrollAutoRefreshDelay = _scrollAutoRefreshDelay;
@synthesize rangeOfFoundString = _rangeOfFoundString;
@synthesize highlightsForArray = _highlightsForArray;


#pragma mark - Class methods

+ (void)initialize
{
    if (self == [PreviewSearchView class])
        _highlightingSupported = [self conformsToProtocol:@protocol(UITextInput)];
}

#pragma mark - Private methods


- (UIView *)addHighlightAtRect:(CGRect)frame
{
    UIView *highlight = [[UIView alloc] initWithFrame:frame];
    highlight.layer.cornerRadius = _highlightCornerRadius < 0.0 ? frame.size.height * 0.2 : _highlightCornerRadius;
    highlight.backgroundColor = _secondaryHighlightColor;
    [_secondaryHighlights addObject:highlight];
    [self insertSubview:highlight belowSubview:[self viewWithTag:UIDocumentViewTag]];
    return highlight;
}



- (NSMutableArray *)addHighlightAtTextRange:(UITextRange *)textRange
{
    NSMutableArray *highlightsForRange = [[NSMutableArray alloc] init];
    

#ifdef __IPHONE_6_0
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_6_0)
    {

        CGRect previousRect = CGRectZero;
        NSArray *highlightRects = [self selectionRectsForRange:textRange];

        for (UITextSelectionRect *selectionRect in highlightRects)
        {
            CGRect currentRect = selectionRect.rect;
            if ((currentRect.origin.y == previousRect.origin.y) && (currentRect.origin.x == CGRectGetMaxX(previousRect)) && (currentRect.size.height == previousRect.size.height))
            {

                previousRect = CGRectMake(previousRect.origin.x, previousRect.origin.y, previousRect.size.width + currentRect.size.width, previousRect.size.height);
            }
            else
            {

                [highlightsForRange addObject:[self addHighlightAtRect:previousRect]];
                previousRect = currentRect;
            }
        }

        [highlightsForRange addObject:[self addHighlightAtRect:previousRect]];
        
    }
    else
        
#endif
    {
      
        CGRect previousRect = CGRectZero;
        UITextPosition *start = textRange.start;
        UITextPosition *end = textRange.end;
        id <UITextInputTokenizer> tokenizer = [self tokenizer];
        BOOL hasMoreLines;
        do {
           
            UITextPosition *lineEnd = [tokenizer positionFromPosition:start toBoundary:UITextGranularityLine inDirection:UITextStorageDirectionForward];
        
            if ([self offsetFromPosition:lineEnd toPosition:end] == 0)
            {
                hasMoreLines = NO;
                textRange = [self textRangeFromPosition:start toPosition:end];
            }
            else
            {
                hasMoreLines = YES;
                textRange = [self textRangeFromPosition:start toPosition:lineEnd];
                start = lineEnd;
            }
            previousRect = [self firstRectForRange:textRange];
            [highlightsForRange addObject:[self addHighlightAtRect:previousRect]];
            
          
        } while (hasMoreLines);
    }
    return highlightsForRange;
    
}






- (void)initializeHighlights
{

    [self initializePrimaryHighlights];
    [self initializeSecondaryHighlights];
}


- (void)initializePrimaryHighlights
{


    for (UIView *hl in _primaryHighlights)
    {
        hl.backgroundColor = _secondaryHighlightColor;
        [_secondaryHighlights addObject:hl];
    }
    [_primaryHighlights removeAllObjects];
}


- (void)initializeSecondaryHighlights
{
    

    for (UIView *hl in _secondaryHighlights) {

        [hl removeFromSuperview];
    }
    [_secondaryHighlights removeAllObjects];
    

    if (_primaryHighlights.count)
    {

        NSValue *rangeValue = [NSValue valueWithRange:_rangeOfFoundString];
        NSMutableArray *primaryHighlights = [_highlightsByRange objectForKey:rangeValue];
        

        
        [_highlightsByRange removeAllObjects];
        [_highlightsByRange setObject:primaryHighlights forKey:rangeValue];
    }
    else {

        [_highlightsByRange removeAllObjects];
    }
    

    _performedNewScroll = YES;
}


- (void)scrollEnded
{

    [self highlightOccurrencesInMaskedVisibleRange];
    

    [_autoRefreshTimer invalidate];
    _autoRefreshTimer = nil;
    

    _performedNewScroll = NO;
}


- (void)setPrimaryHighlightAtRange:(NSRange)range
{
   
    [self initializePrimaryHighlights];
    NSValue *rangeValue = [NSValue valueWithRange:range];
    NSMutableArray *highlightsForRange = [_highlightsByRange objectForKey:rangeValue];
    for (UIView *hl in highlightsForRange)
    {
        hl.backgroundColor = _primaryHighlightColor;
        [_primaryHighlights addObject:hl];
        [_secondaryHighlights removeObject:hl];
    }
}

#pragma mark - Overrides

- (BOOL)becomeFirstResponder
{
    if (self.editable)
        [self resetSearch];
    return [super becomeFirstResponder];
}



- (id)initWithFrame:(CGRect)frame
{
#ifdef __IPHONE_7_0
    if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1)
        return [self initWithFrame:frame textContainer:nil];
    else
#endif
    {
        self = [super initWithFrame:frame];
        if (self && _highlightingSupported)
            [self initialize];
        return self;
    }
}


#ifdef __IPHONE_7_0

- (instancetype)initWithFrame:(CGRect)frame textContainer:(NSTextContainer *)textContainer
{
    NSTextStorage *textStorage = [[NSTextStorage alloc] init];
    NSLayoutManager *layoutManager = [[NSLayoutManager alloc] init];
    [textStorage addLayoutManager:layoutManager];
    if (!textContainer)
        textContainer = [[NSTextContainer alloc] initWithSize:frame.size];
    [layoutManager addTextContainer:textContainer];
    self = [super initWithFrame:frame textContainer:textContainer];
    if (self && _highlightingSupported)
        [self initialize];
    return self;
}
#endif


- (void)initialize
{

    _highlightCornerRadius = -1.0;
    _highlightsByRange = [[NSMutableDictionary alloc] init];
    _highlightSearchResults = YES;
    _maxHighlightedMatches = 100;
    _scrollAutoRefreshDelay = 0.2;
    _primaryHighlights = [[NSMutableArray alloc] init];
    _primaryHighlightColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:1.0 alpha:1.0];
    _secondaryHighlights = [[NSMutableOrderedSet alloc] init];
    _secondaryHighlightColor = [UIColor colorWithRed:100.0/255.0 green:240.0/255.0 blue:1.0 alpha:1.0];
    _isRecover = NO;

    

    for (UIView *view in self.subviews)
    {
        if ([view isKindOfClass:NSClassFromString(@"_UITextContainerView")] || [view isKindOfClass:NSClassFromString(@"UIWebDocumentView")])
        {
            view.tag = UIDocumentViewTag;
            break;
        }
    }
}


- (void)setContentOffset:(CGPoint)contentOffset
{
    
    if (_isRecover == NO) {
        
        [super setContentOffset:contentOffset];
        
        if (_highlightingSupported && _highlightSearchResults)
        {
            

            _performedNewScroll = YES;
            

            if (!_shouldUpdateScanIndex)
                _shouldUpdateScanIndex = ([self.panGestureRecognizer velocityInView:self].y != 0.0);
            
            if (_regex && _scrollAutoRefreshDelay && !_autoRefreshTimer)
            {
                
                _autoRefreshTimer = [NSTimer timerWithTimeInterval:_scrollAutoRefreshDelay target:self selector:@selector(highlightOccurrencesInMaskedVisibleRange) userInfo:nil repeats:YES];
                [[NSRunLoop mainRunLoop] addTimer:_autoRefreshTimer forMode:UITrackingRunLoopMode];
            }
            

            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(scrollEnded) object:nil];
            [self performSelector:@selector(scrollEnded) withObject:nil afterDelay:0.1];
        }
    }
    else {
        

        
        if (contentOffset.x == 500.0) {
            
            _isRecover = NO;
        }
    }
}




- (void)setFrame:(CGRect)frame
{
    
    if (_highlightingSupported && _highlightsByRange.count)
        [self initializeHighlights];
    [super setFrame:frame];
}


- (void)setScrollAutoRefreshDelay:(NSTimeInterval)scrollAutoRefreshDelay
{
    _scrollAutoRefreshDelay = (scrollAutoRefreshDelay > 0.0 && scrollAutoRefreshDelay < 0.1) ? 0.1 : scrollAutoRefreshDelay;
}


#ifdef __IPHONE_7_0
- (void)setText:(NSString *)text
{
    [super setText:text];
    if (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1 && !_hasAppliediOS7Bugfix && text.length > 1)
    {
        [self select:self];
        [self setSelectedTextRange:nil];
        _hasAppliediOS7Bugfix = YES;
    }
    
}
#endif

#pragma mark - Public methods

#pragma mark -- Search --


- (NSString *)foundString
{
    return [self.text substringWithRange:_rangeOfFoundString];
}


- (void)resetSearch
{
    if (_highlightingSupported)
    {
        [self initializeHighlights];
        [_autoRefreshTimer invalidate];
        _autoRefreshTimer = nil;
    }
    _rangeOfFoundString = NSMakeRange(NSNotFound,0);
    _regex = nil;
    _scanIndex = 0;
    _searchRange = NSMakeRange(0,0);
}

#pragma mark ---- Regex search ----



- (BOOL)scrollToMatch:(NSString *)pattern
{
    return [self scrollToMatch:pattern searchOptions:0 range:NSMakeRange(0, self.text.length) back:NO];
}

- (BOOL)scrollToMatch:(NSString *)pattern searchOptions:(NSRegularExpressionOptions)options
{
    return [self scrollToMatch:pattern searchOptions:options range:NSMakeRange(0, self.text.length) back:NO];
}


#pragma mark ---- String search ----



- (BOOL)scrollBackToString:(NSString *)stringToFind searchOptions:(NSRegularExpressionOptions)options {
    
    [self scrollRangeToVisible:_currentMatchRange consideringInsets:YES];
    
    return YES;
}


- (BOOL)scrollToString:(NSString *)stringToFind
{
    return [self scrollToString:stringToFind searchOptions:0 range:NSMakeRange(0, self.text.length) back:NO];
}

- (BOOL)scrollToString:(NSString *)stringToFind searchOptions:(NSRegularExpressionOptions)options back:(BOOL)isBack
{

    return [self scrollToString:stringToFind searchOptions:options range:NSMakeRange(0, self.text.length) back:isBack];
}

- (BOOL)scrollToString:(NSString *)stringToFind searchOptions:(NSRegularExpressionOptions)options range:(NSRange)range back:(BOOL)isBack
{
    
    
    if (!stringToFind)
    {
#if DEBUG
        
#endif

        return NO;
    }
    

    stringToFind = [NSRegularExpression escapedPatternForString:stringToFind];
    

    if (_regex)
    {
        

        NSString *lcStringToFind = [stringToFind lowercaseString];
        
        NSString *lcFoundString = [_regex.pattern lowercaseString];
        if (!([lcStringToFind hasPrefix:lcFoundString] || [lcFoundString hasPrefix:lcStringToFind]))
            _scanIndex += _rangeOfFoundString.length;
    }
    

    return [self scrollToMatch:stringToFind searchOptions:options range:range back:isBack];
}

- (BOOL)scrollToMatch:(NSString *)stringToFind searchOptions:(NSRegularExpressionOptions)options range:(NSRange)range back:(BOOL)isBack
{

    range = NSIntersectionRange(NSMakeRange(0, self.text.length), range);
    

    BOOL abort = NO;
    if (!stringToFind)
    {
#if DEBUG
        
#endif
        abort = YES;
    }
    else if (range.length == 0)
    {
#if DEBUG
        
#endif
        abort = YES;
    }
    if (abort)
    {
        [self resetSearch];
        return NO;
    }


    BOOL samePattern = [stringToFind isEqualToString:_regex.pattern];

    BOOL sameOptions = (options == _regex.options);
    

    BOOL sameSearchRange = NSEqualRanges(range, _searchRange);
    

    _searchRange = range;
    

    NSError *error;
    

    _regex = [[NSRegularExpression alloc] initWithPattern:stringToFind options:options error:&error];
    
    if (error)
    {
#if DEBUG
        
#endif
        [self resetSearch];
        return NO;
    }
    
    if (_highlightingSupported && _highlightSearchResults)
    {

        [self initializePrimaryHighlights];
        

        if (!(samePattern && sameOptions && sameSearchRange)) {
            

            [self initializeSecondaryHighlights];
        }
    }
    

    if (samePattern && sameSearchRange && sameOptions)
    {
        

        if (_scanIndex <= range.location || _scanIndex >= (range.location + range.length)) {
            if (isBack) {
                _scanIndex = self.text.length;
            }
            else {
               
                _scanIndex = range.location;
                
            }
        }
        

        if (_scanIndex && samePattern) {
            if (isBack) {
                
                _scanIndex = _scanIndex - 1;
                
            }
            else {
                
                _scanIndex += _rangeOfFoundString.length;
                
            }
        }
    }
    else {

        
        _scanIndex = range.location;
    }

    
    NSRange matchRange;
    if (isBack) {
        
        NSArray* result = [_regex matchesInString:self.text options:0 range:NSMakeRange(range.location, _scanIndex)];
        
        NSRange lastMatchRange = [[result lastObject] range];
        
        matchRange = lastMatchRange;
        
        _scanIndex=matchRange.location;
        
        if (_scanIndex <= range.location ) {
       
         matchRange = [_regex rangeOfFirstMatchInString:self.text options:0 range:NSMakeRange(_scanIndex, range.location + range.length - _scanIndex)];
        
            if (matchRange.location == NSNotFound) {
                
                _scanIndex = range.location;
            }
            else{
                _scanIndex = self.text.length;
            }
        }
        
        matchRange = [_regex rangeOfFirstMatchInString:self.text options:0 range:NSMakeRange(_scanIndex, range.location + range.length - _scanIndex)];
    }
    
    else if(!isBack) {
        
        matchRange = [_regex rangeOfFirstMatchInString:self.text options:0 range:NSMakeRange(_scanIndex, range.location + range.length - _scanIndex)];
        
    }
    

    if (matchRange.location == NSNotFound )
    {
        if (_scanIndex)
        {
            _scanIndex = range.location;
            
            return [self scrollToMatch:stringToFind searchOptions:options range:range back:isBack];
            
        }
        _regex = nil;
        _rangeOfFoundString = NSMakeRange(NSNotFound, 0);
        return NO;
    }
    

    _rangeOfFoundString = matchRange;
    

    _scanIndex = matchRange.location;
    
    _shouldUpdateScanIndex = NO;
    

    if (_highlightingSupported && _highlightSearchResults) {
        
        [self highlightOccurrencesInMaskedVisibleRange];
    }
    

    [self scrollRangeToVisible:matchRange consideringInsets:YES];
    
    return YES;
}


- (void)highlightOccurrencesInMaskedVisibleRange
{

    if (_regex)
    {
        

        if (_performedNewScroll)
        {
           
            UITextPosition *visibleStartPosition;
            NSRange visibleRange = [self visibleRangeConsideringInsets:YES startPosition:&visibleStartPosition endPosition:NULL];
            
          
            NSRange maskedRange = NSIntersectionRange(_searchRange, visibleRange);
            
            NSMutableArray *rangeValues = [[NSMutableArray alloc] init];
            [_regex enumerateMatchesInString:self.text options:0 range:maskedRange usingBlock:^(NSTextCheckingResult *match, NSMatchingFlags flags, BOOL *stop){
                
                NSValue *rangeValue = [NSValue valueWithRange:match.range];
                
                [rangeValues addObject:rangeValue];
                
               
                
            }];

            if (rangeValues.count)
            {
                

                NSMutableArray *rangesArray = [rangeValues mutableCopy];
                NSMutableIndexSet *indexesToRemove = [[NSMutableIndexSet alloc] init];

                [rangeValues enumerateObjectsUsingBlock:^(NSValue *rangeValue, NSUInteger idx, BOOL *stop){
                    if ([_highlightsByRange objectForKey:rangeValue]) {
                        [indexesToRemove addIndex:idx];
                    }
                }];
                
                [rangesArray removeObjectsAtIndexes:indexesToRemove];
                indexesToRemove = nil;
                

                if (rangesArray.count)
                {

                    NSValue *firstRangeValue = [rangesArray objectAtIndex:0];
                    
                    NSRange previousRange = [firstRangeValue rangeValue];
                    
                    UITextPosition *start = [self positionFromPosition:visibleStartPosition offset:(previousRange.location - visibleRange.location)];
                    UITextPosition *end = [self positionFromPosition:start offset:previousRange.length];
                    UITextRange *textRange = [self textRangeFromPosition:start toPosition:end];
                    

                    [_highlightsByRange setObject:[self addHighlightAtTextRange:textRange] forKey:firstRangeValue];
                    
                    
                    if (rangesArray.count > 1)
                    {
                        
         
                        for (NSUInteger idx=1; idx < rangesArray.count; idx++)
                        {
                           
                            NSValue *rangeValue = [rangesArray objectAtIndex:idx];
                            
                            NSRange range = [rangeValue rangeValue];
                            
                          
                            
                            start = [self positionFromPosition:end offset:range.location - (previousRange.location + previousRange.length)];
                            end = [self positionFromPosition:start offset:range.length];
                            textRange = [self textRangeFromPosition:start toPosition:end];
                            [_highlightsByRange setObject:[self addHighlightAtTextRange:textRange] forKey:rangeValue];
                            previousRange = range;
                            
                        }
                    }
                    
                
                    NSInteger remaining = _maxHighlightedMatches - _highlightsByRange.count;
                    
                    if (remaining < 0)
                    {
                        
                        
                        NSInteger tempMin = visibleRange.location - visibleRange.length;
                        NSUInteger min = tempMin > 0 ? tempMin : 0;
                        NSUInteger max = min + 3 * visibleRange.length;
                      
                        NSMutableArray *keysToRemove = [[NSMutableArray alloc] init];
                        [_highlightsByRange enumerateKeysAndObjectsUsingBlock:^(NSValue *rangeValue, NSArray *highlightsForRange, BOOL *stop){
                            
                            
                            NSUInteger location = [rangeValue rangeValue].location;
                            if ((location < min || location > max) && location != _rangeOfFoundString.location)
                            {
                                for (UIView *hl in highlightsForRange)
                                {
                                    [hl removeFromSuperview];
                                    [_secondaryHighlights removeObject:hl];
                                }
                                [keysToRemove addObject:rangeValue];
                            }
                            
                        }];
                        [_highlightsByRange removeObjectsForKeys:keysToRemove];
                    }
                }
            }
            
           
            if (_shouldUpdateScanIndex)
                _scanIndex = visibleRange.location + (_regex ? visibleRange.length : 0);
        }
       
        [self setPrimaryHighlightAtRange:_rangeOfFoundString];
        
    }
}

#pragma mark -- Misc --


- (void)scrollRangeToVisible:(NSRange)range consideringInsets:(BOOL)considerInsets
{
   
#ifdef __IPHONE_7_0
    if (considerInsets && (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1))
    {
      
        UITextPosition *startPosition = [self positionFromPosition:self.beginningOfDocument offset:range.location];
        UITextPosition *endPosition = [self positionFromPosition:startPosition offset:range.length];
        UITextRange *textRange = [self textRangeFromPosition:startPosition toPosition:endPosition];
        CGRect rect = [self firstRectForRange:textRange];
        
      
        [self scrollRectToVisible:rect animated:YES consideringInsets:YES];
    }
    else
#endif
        [super scrollRangeToVisible:range];
}


- (void)scrollRectToVisible:(CGRect)rect animated:(BOOL)animated consideringInsets:(BOOL)considerInsets
{

#ifdef __IPHONE_7_0
    if (considerInsets && (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_6_1))
    {

        CGRect bounds = self.bounds;
        UIEdgeInsets contentInset = self.contentInset;
        CGRect visibleRect = [self visibleRectConsideringInsets:YES];
        
  
        if (!CGRectContainsRect(visibleRect, rect))
        {
            CGPoint contentOffset = self.contentOffset;
            
            if (rect.origin.y < visibleRect.origin.y)
                
                contentOffset.y = rect.origin.y - contentInset.top;
            else
               
                contentOffset.y = rect.origin.y + contentInset.bottom + rect.size.height - bounds.size.height;
            [self setContentOffset:contentOffset animated:animated];
        }
    }
    else
#endif
        [super scrollRectToVisible:rect animated:animated];
}


- (NSRange)visibleRangeConsideringInsets:(BOOL)considerInsets
{
   
    return [self visibleRangeConsideringInsets:considerInsets startPosition:NULL endPosition:NULL];
}


- (NSRange)visibleRangeConsideringInsets:(BOOL)considerInsets startPosition:(UITextPosition *__autoreleasing *)startPosition endPosition:(UITextPosition *__autoreleasing *)endPosition
{
    
    CGRect visibleRect = [self visibleRectConsideringInsets:considerInsets];

    CGPoint startPoint = visibleRect.origin;

    CGPoint endPoint = CGPointMake(CGRectGetMaxX(visibleRect), CGRectGetMaxY(visibleRect));
    

    UITextPosition *start = [self characterRangeAtPoint:startPoint].start;
    UITextPosition *end = [self characterRangeAtPoint:endPoint].end;
    

    if (startPosition) {
        *startPosition = start;
    }

    if (endPosition) {
        *endPosition = end;
    }
    
    return NSMakeRange([self offsetFromPosition:self.beginningOfDocument toPosition:start], [self offsetFromPosition:start toPosition:end]);
}



- (CGRect)visibleRectConsideringInsets:(BOOL)considerInsets
{
   
    CGRect bounds = self.bounds;
    if (considerInsets)
    {
        UIEdgeInsets contentInset = self.contentInset;
        CGRect visibleRect = self.bounds;
        visibleRect.origin.x += contentInset.left;
        visibleRect.origin.y += contentInset.top;
        visibleRect.size.width -= (contentInset.left + contentInset.right);
        visibleRect.size.height -= (contentInset.top + contentInset.bottom);
        return visibleRect;
    }
    return bounds;
}
@end


