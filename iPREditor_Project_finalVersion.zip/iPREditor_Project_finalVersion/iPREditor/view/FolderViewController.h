//
//  FolderViewController.h
//  iPREditor
//
//  Created by admin on 10/28/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FolderViewController : UITableViewController<UIDocumentInteractionControllerDelegate>

@property (nonatomic, copy) NSString* headTitle;
@property (nonatomic, copy) NSString* currentPath;
//@property (nonatomic, ) NSMutableArray* selectedFiles;

-(void) setSelectedFiles: (NSMutableArray *) n;


@end
