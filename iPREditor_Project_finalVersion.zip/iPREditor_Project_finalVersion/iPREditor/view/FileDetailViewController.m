//
//  FileDetailViewController.m
//  iPREditor
//
//  Created by admin on 10/29/15.
//  Copyright (c) 2015 admin. All rights reserved.
//
#import "AppDelegate.h"
#import "FileDetailViewController.h"
#import "FileTool.h"

@interface FileDetailViewController ()

@end


@implementation FileDetailViewController

AppDelegate* delegate;
NSDictionary* attributs;

- (void)viewDidLoad {
    [super viewDidLoad];
    delegate = [UIApplication sharedApplication].delegate;
    attributs = [delegate.fileTool getAttributes:[delegate.documentDirectory stringByAppendingPathComponent:self.currentPath]];
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(backClicked:)];
}

- (void)viewDidAppear:(BOOL)animated {
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)editClicked: (id)sender {
    
    NSIndexPath* path = [NSIndexPath indexPathForRow:0 inSection:0];
    UITableViewCell* name_cell = [self.tableView cellForRowAtIndexPath:path];
    
    UITextField* field = (UITextField*)[name_cell viewWithTag:1];
    
    //点击了Edit
    if ([[sender title] isEqualToString:@"Edit"]) {
        
        field.userInteractionEnabled = YES;
        field.textColor = [UIColor blackColor];
        self.navigationItem.rightBarButtonItem.title = @"Done";
    }
    //点击了Done
    else {
        
        field.userInteractionEnabled = NO;
        field.textColor = [UIColor grayColor];
        self.navigationItem.rightBarButtonItem.title = @"Edit";
        
        NSString* after_trim = [field.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        field.text = after_trim;
        //不同，需要改名
        if ([after_trim isEqualToString:self.currentFile] == NO) {
            NSString* source = [delegate.documentDirectory stringByAppendingPathComponent:self.currentPath];
            NSString* target = [NSString stringWithFormat:@"%@/%@",[source stringByDeletingLastPathComponent],after_trim];
            [delegate.fileTool rename:source to:target];
        }
    }
}

- (void)backClicked: (id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


#pragma mark - Table view data source

//静态单元格不起作用
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 2;

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if (section == 0) {
        return 1;
    }
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        return @"File name";
    }
    return @"PROPORTIES";
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"detail_cell";
    UITableViewCell* cell = [self.tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
    }
    else {
        
        UITextField* field = (UITextField*)[cell viewWithTag:1];
        field.frame = CGRectMake(0, 0, SCREEN_WIDTH, 44);
    }
    //文件名
    if (indexPath.section == 0) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 5)];
        [cell.contentView addSubview:view];
        
        UITextField* field = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
       
        field.leftView = view;
        field.leftViewMode = UITextFieldViewModeAlways;
        field.userInteractionEnabled = NO;
        field.tag = 1;
        field.textColor = [UIColor grayColor];
        field.text = self.currentFile;
        [field setNeedsDisplay];
        [cell.contentView addSubview:field];
    }
    else {
        cell.textLabel.text = @"Size";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ byte",[attributs objectForKey:@"NSFileSize"]];
        if (indexPath.row == 0) {
            cell.textLabel.text = @"Last Modified";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",[attributs objectForKey:@"NSFileModificationDate"]];
        }
    }
    
    return cell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    
    NSIndexPath* path = [NSIndexPath indexPathForRow:0 inSection:0];
    
    UITableViewCell* cell = [self.tableView cellForRowAtIndexPath:path];
    
    UITextField* field = (UITextField*)[cell viewWithTag:1];

    field.frame = CGRectMake(0, 0, SCREEN_WIDTH, 44);
    
}

@end
