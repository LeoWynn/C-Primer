//
//  MainTableViewController.m
//  iPREditor
//
//  Created by admin on 10/28/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "MainViewController.h"
#import "FolderViewController.h"
#import "FileTool.h"
#import "AppDelegate.h"
#import "FolderViewController.h"
#import "SSZipArchive.h"
#import "PRTabbarController.h"
#import "AboutViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

NSString* temDirectory;
AppDelegate* delegate;
UIButton *info;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    delegate = [UIApplication sharedApplication].delegate;

    temDirectory = NSTemporaryDirectory();
    
    self.tableView.tableFooterView=[[UIView alloc]init];
   
    delegate.navi = self.navigationController;
    
    UIBarButtonItem* about = [[UIBarButtonItem alloc] initWithTitle:@"About" style:UIBarButtonItemStylePlain target:self action:@selector(aboutClicked:)];
    
    self.navigationItem.leftBarButtonItem = about;
    
    //从第三方应用打开，从这条分支走
    if (delegate.goToFile) {
        
        NSString* fileName = [[delegate.fileURL relativePath] lastPathComponent];
        
        NSLog(@"fileName: %@", fileName);
        
        //打开的是zip，需要解压
        if ([[[fileName pathExtension] lowercaseString] isEqualToString:@"zip"]) {
            
            
            FolderViewController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"story_folderViewController"];
            
            if (view == NULL) {
                view = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"story_folderViewController"];
            }
            [view setValue:[fileName stringByDeletingPathExtension] forKey:@"headTitle"];

            [view setValue:[NSString stringWithFormat:@"PrFile/%@",[fileName stringByDeletingPathExtension]] forKey:@"currentPath"];

            delegate.goToFile = NO;
            
            [self.navigationController pushViewController:view animated:YES];
            
        }
        else {
            
            
            [delegate.fileTool removeFile:[delegate.documentDirectory stringByAppendingPathComponent:@"Inbox"]];
            
            PRTabbarController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"story_prTabBar"];
            if (view == NULL) {
                view = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"story_prTabBar"];
            }
            
            delegate.temFilePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.tem",fileName]];
            
            [[NSString stringWithContentsOfFile:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]] encoding:NSUTF8StringEncoding error:nil] writeToFile:delegate.temFilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
            
            for (int i = 0; i < [[view viewControllers] count]; i++) {

                [[[[[view viewControllers] objectAtIndex:i] viewControllers] objectAtIndex:0] setValue:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]] forKey:@"fullPath"];
            }

            delegate.goToFile = NO;
            [self.navigationController pushViewController:view animated:YES];
        }
    }
    
   
}

-(BOOL)shouldAutorotate{
    return YES;
}

-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator{
    
    
}


- (void)aboutClicked: (id)sender {
    
    AboutViewController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"aboutViewController"];
    
    [self.navigationController pushViewController:view animated:YES];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO];
    
}

#pragma mark - Table view data source

/*
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 2;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"local_cell" forIndexPath:indexPath];
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"segue_to_localFile"]) {
        
        [[segue destinationViewController] setValue:@"Local" forKey:@"headTitle"];
        [[segue destinationViewController] setValue:@"PrFile" forKey:@"currentPath"];
    }
    else if ([segue.identifier isEqualToString:@"segue_to_configFile"]) {
        
        [[segue destinationViewController] setValue:@"Config" forKey:@"headTitle"];
        [[segue destinationViewController] setValue:@"Config" forKey:@"currentPath"];
    }
}


@end
