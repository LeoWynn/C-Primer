//
//  PreviewController.h
//  iPREditor
//
//  Created by admin on 11/4/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreviewController : UIViewController<UITextViewDelegate>
@property (nonatomic, copy) NSString* fullPath;
@property (nonatomic,strong)UITextView *textView;
@property (nonatomic, retain) NSMutableDictionary* dictionary;

@end
