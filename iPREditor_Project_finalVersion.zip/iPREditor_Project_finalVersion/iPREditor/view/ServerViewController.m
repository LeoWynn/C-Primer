//
//  ServerViewController.m
//  iPREditor
//
//  Created by admin on 10/31/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "ServerViewController.h"
#import "FileTool.h"
#import "FolderViewController.h"
#import "AppDelegate.h"

@interface ServerViewController ()

@end

@implementation ServerViewController

AppDelegate* delegate;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    delegate = [UIApplication sharedApplication].delegate;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(backClicked:)];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)backClicked: (id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)getClicked:(id)sender {
    
    NSError* err;
    
    NSURL* url = [NSURL URLWithString:self.server.text];
    
    NSString* content = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&err];
    
    if (err != nil) {
        return;
    }
    
    NSString* fileName = [self.server.text lastPathComponent];

    [delegate.fileTool write:content at:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]] append:NO];
    
    FolderViewController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"story_folderViewController"];
    [view setValue:@"Local" forKey:@"headTitle"];
    [view setValue:@"PrFile" forKey:@"currentPath"];
    [self.navigationController pushViewController:view animated:YES];
    
}

- (IBAction)backTapped:(id)sender {
    
    [self.server resignFirstResponder];
}


@end
