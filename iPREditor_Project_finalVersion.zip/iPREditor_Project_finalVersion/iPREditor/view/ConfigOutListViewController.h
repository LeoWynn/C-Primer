//
//  ConfigOutListViewController.h
//  iPREditor
//
//  Created by admin on 11/30/15.
//  Copyright © 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfigOutListViewController : UITableViewController

@property (nonatomic,copy) NSString* keyLabel;
@property (nonatomic,copy) NSString* keyPath;
@property (nonatomic,retain) id extra;
@property (nonatomic,retain) NSMutableDictionary* dictionary;

@end
