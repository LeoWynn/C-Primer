//
//  PRTabbarController.h
//  iPREditor
//
//  Created by admin on 11/4/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PRTabbarController : UITabBarController <UITabBarControllerDelegate>

@end
