//
//  TextViewController.h
//  iPREditor
//
//  Created by admin on 11/10/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextViewController : UITableViewController<UITextViewDelegate>

@property (nonatomic,copy) NSString* keyLabel;
@property (nonatomic,copy) NSString* keyPath;
@property (nonatomic,copy) NSString* keyValue;
@property (nonatomic,strong) NSString* control;
@property (nonatomic,retain) NSMutableDictionary* dictionary;

@property (nonatomic,retain) id extra;
@property (nonatomic) NSNumber* index;

@end
