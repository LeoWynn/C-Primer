//
//  SettingViewController.h
//  iPREditor
//
//  Created by admin on 11/19/15.
//  Copyright © 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>

@property (nonatomic, copy) NSString* fullPath;
@property (nonatomic, retain) UITableView* tableView;

@end
