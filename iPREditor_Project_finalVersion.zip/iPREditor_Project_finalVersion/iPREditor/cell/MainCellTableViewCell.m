//
//  MainCellTableViewCell.m
//  iPREditor
//
//  Created by admin on 11/3/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "MainCellTableViewCell.h"

@implementation MainCellTableViewCell


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];

}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    _mainkeyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 5, SCREEN_WIDTH - 130, 40)];
    _subKeyLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 30, SCREEN_WIDTH - 100, 20)];
    //_subKeyLabel.font = SYSTEM_SECONDARY_FONT_SIZE;  //[UIFont systemFontOfSize:14.0];
    _subKeyLabel.textColor = [UIColor grayColor];
    _subTypeLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 90, 15, 60, 20)];
    //_subTypeLabel.font = SYSTEM_SECONDARY_FONT_SIZE; //[UIFont systemFontOfSize:14.0];
    _subTypeLabel.textColor = [UIColor grayColor];
    _bgImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 54)];
    _imageLine = [[UIImageView alloc] initWithFrame:CGRectMake(0, 53, SCREEN_WIDTH, 1)];
    //_button = [UIButton buttonWithType:UIButtonTypeCustom];
    //_button.frame = CGRectMake(0, 0, 420, 50);
    //[_button addTarget:self action:@selector(doButton:) forControlEvents:UIControlEventTouchUpInside];
    
    //_arrowButton = [[UIButton alloc] initWithFrame:CGRectMake(2, 17, 16,16)];
    
    _arrowImage = [[UIImageView alloc] initWithFrame:CGRectMake(2, 17, 16,16)];
    //[_arrowButton setBackgroundImage:[UIImage imageNamed:@"arrow_right_32px.png"] forState:UIControlStateNormal];
    
    //[self.contentView addSubview:_bgImage];
    //[self.contentView addSubview:_arrowButton];
    [self.contentView addSubview:_arrowImage];
    [self.contentView addSubview:_mainkeyLabel];
    [self.contentView addSubview:_subKeyLabel];
    [self.contentView addSubview:_subTypeLabel];
    [self.contentView addSubview:_imageLine];
    
   // [self.contentView addSubview:_button];
    return self;
    
}
- (void)doButton: (id)sender {
    
}
- (void)drawRect:(CGRect)rect {
    
    //if (_treeNode.nodeLevel == 0) {
    
    if ([_treeNode.control isEqualToString:PARENTNODE]) {
    
        _mainkeyLabel.frame = CGRectMake(20, 5, SCREEN_WIDTH - 80, 40);
    }
    else {
        
        _mainkeyLabel.frame = CGRectMake(20, 5, SCREEN_WIDTH - 130, 40);
    }
    _subKeyLabel.frame = CGRectMake(7, 30, SCREEN_WIDTH - 100, 20);
    _subTypeLabel.frame = CGRectMake(SCREEN_WIDTH - 90, 15, 60, 20);
    _imageLine.frame = CGRectMake(0, 53, SCREEN_WIDTH, 1);
    //_arrowButton.frame = CGRectMake(2, 17, 16,16);
    _arrowImage.frame = CGRectMake(2, 17, 16,16);
    
    [self setIndention];
    
}
- (void)setIndention {

    
    CGRect main = _mainkeyLabel.frame;
    main.origin.x = _treeNode.nodeLevel*20+20;
    _mainkeyLabel.frame = main;
    
    CGRect sub = _subKeyLabel.frame;
    sub.origin.x = _treeNode.nodeLevel*20+20+7;
    _subKeyLabel.frame = sub;
    
    //CGRect arrow = _arrowButton.frame;
    //arrow.origin.x = _treeNode.nodeLevel*20+2;
    //_arrowButton.frame = arrow;
    CGRect arrow = _arrowImage.frame;
    arrow.origin.x = _treeNode.nodeLevel*20 + 2;
    _arrowImage.frame = arrow;
    
    
    CGRect bgImage = _bgImage.frame;
    bgImage.origin.x = _treeNode.nodeLevel*20;
    _bgImage.frame = bgImage;
}

@end
