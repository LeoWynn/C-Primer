//
//  FXCheckBox.h
//  text
//
//  Created by jett on 15/11/24.
//  Copyright (c) 2015年 jett. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol FXCheckBoxProtocol;

@interface FXCheckBox : UIButton{
    BOOL _checked;
}
@property (nonatomic, assign) BOOL checked;
@property (nonatomic, weak) id<FXCheckBoxProtocol> delegate;
-(id)initWithFrame:(CGRect)frame;
@end


@protocol FXCheckBoxProtocol <NSObject>
@optional
-(void)didSelectCheckBox:(FXCheckBox *)checkBox checked:(BOOL)check;
@end