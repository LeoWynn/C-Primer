//
//  PlistTableCell.m
//  test
//
//  Created by jett on 15/11/6.
//  Copyright (c) 2015年 jett. All rights reserved.
//

#import "PlistTableCell.h"

@implementation PlistTableCell{
    NSUInteger mainKeyXInset;
    NSUInteger mainKeyYInset;
    NSUInteger mainKeyWidth;
    NSUInteger mainKeyHeight;
    
    NSUInteger subKeyXInset;
    NSUInteger subKeyYInset;
    NSUInteger subKeyWidth;
    NSUInteger subKeyHeith;
    NSUInteger subKeyYoffset;
    
    NSUInteger cellWidth;
    NSUInteger cellHeight;
}

- (void) setInset{
    cellWidth = CGRectGetWidth(self.contentView.frame);
    cellHeight = CGRectGetHeight(self.contentView.frame);
    
    mainKeyXInset = 25;
    mainKeyYInset = 3;
    
    mainKeyHeight = cellHeight/2;
    mainKeyWidth = cellWidth -  mainKeyXInset;
    
    
    subKeyXInset = 30;
    subKeyYoffset = -5;
    
    subKeyYInset = cellHeight - mainKeyHeight - mainKeyYInset - subKeyYoffset;
    subKeyWidth = cellWidth - subKeyXInset;
    subKeyHeith = cellHeight - mainKeyHeight - mainKeyYInset - subKeyYoffset;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self setInset];
        self.mainkeyLable = [[UILabel alloc] initWithFrame:CGRectMake(mainKeyXInset, mainKeyYInset, mainKeyWidth , mainKeyHeight)];
        
        self.subkeyLable = [[UILabel alloc] initWithFrame:CGRectMake(subKeyXInset, subKeyYInset, subKeyWidth , subKeyHeith)];
        
        self.mainkeyLable.font = [UIFont fontWithName:nil size:17];
        self.subkeyLable.font = [UIFont fontWithName:nil size:17];
        
        self.mainkeyLable.textAlignment = NSTextAlignmentLeft;
        self.subkeyLable.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:self.mainkeyLable];
        [self.contentView addSubview:self.subkeyLable];
        self.isExpand = NO;
        self.isMainKey = NO;
        
//        self.mainkeyLable.layer.borderColor = [UIColor redColor].CGColor;
//        self.mainkeyLable.layer.borderWidth = 1;
//        
//        self.subkeyLable.layer.borderColor = [UIColor redColor].CGColor;
//        self.subkeyLable.layer.borderWidth = 1;
    }
    
    return self;
    
}

- (void) cellWithoutAccessoryAndSubtitle{
    
    self.mainkeyLable.frame = CGRectMake(10, 5, cellWidth - 10, cellHeight -5);
    
    self.mainkeyLable.font = [UIFont fontWithName:nil size:20];
    
    
    self.accessoryType = UITableViewCellAccessoryNone;
    
    self.subkeyLable.text = @"";
    
    self.isMainKey = YES;
    self.isExpand = NO;
}


- (void) cellWithAccessoryButWithoutSubtitle{
    
    NSUInteger xInset = 25;
    
    self.mainkeyLable.frame = CGRectMake(xInset, 5, cellWidth - xInset, cellHeight -5);
    
    self.mainkeyLable.font = [UIFont fontWithName:nil size:17];
    
    self.subkeyLable.text = @"";
    
    self.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    self.isMainKey = NO;
    self.isExpand = NO;
}

- (void) cellWithAccessoryAndSubtitle{
    self.mainkeyLable.font = [UIFont fontWithName:nil size:15];
    self.subkeyLable.font = [UIFont fontWithName:nil size:10];
    self.mainkeyLable.frame = CGRectMake(mainKeyXInset, mainKeyYInset, mainKeyWidth , mainKeyHeight);
    
    self.subkeyLable.frame = CGRectMake(subKeyXInset, subKeyYInset, subKeyWidth , subKeyHeith);
    self.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
}

- (void) cellOfArrayWithItem{
 //   NSUInteger offset = cellWidth/6;
    NSUInteger leftBnWidth = cellWidth*0.75;
    mainKeyYInset = 14;
    
    NSUInteger rightBnXPos =  mainKeyXInset + leftBnWidth + 8;
    NSUInteger rightBnWidth = cellWidth - leftBnWidth - mainKeyXInset + 16;
    
    self.mainkeyLable.frame = CGRectMake(mainKeyXInset, mainKeyYInset, leftBnWidth , mainKeyHeight);
    self.subkeyLable.frame = CGRectMake( rightBnXPos, mainKeyYInset,  rightBnWidth, mainKeyHeight);
    
    self.mainkeyLable.textAlignment = NSTextAlignmentLeft;
    self.subkeyLable.textAlignment = NSTextAlignmentRight;
    self.subkeyLable.font = [UIFont fontWithName:nil size:15];
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
}

//#define CELLTYPE CELLTYPE
- (void) setCellAccessoryType:(UITableViewCellAccessoryType )accessoryType  withSubtitle:(CELLTYPE ) type
{
    if (type == cellwithoutsubtitle) {
        [self cellWithAccessoryButWithoutSubtitle];
        self.accessoryType = accessoryType;
    }else if(type == cellwithsubtitle){
        [self cellWithAccessoryAndSubtitle];
        self.accessoryType = accessoryType;
    }
    
}
@end

