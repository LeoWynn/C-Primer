//
//  CheckViewCell.h
//  iPREditor
//
//  Created by admin on 1/28/16.
//  Copyright © 2016 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckViewCell : UITableViewCell

@property(nonatomic, retain) UIButton* checkBox;
@property(nonatomic, retain) UILabel* label;
@property(nonatomic, strong) NSString* value;

-(void)recoverCheckBox;

@end
