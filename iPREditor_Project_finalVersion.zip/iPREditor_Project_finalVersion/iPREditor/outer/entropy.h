
#ifndef _ENTROPY_FUN_H
#define _ENTROPY_FUN_H

#if defined(__cplusplus)
extern "C"
{
#endif

int entropy_fun(unsigned char buf[], unsigned int len);

#if defined(__cplusplus)
}
#endif

#endif
