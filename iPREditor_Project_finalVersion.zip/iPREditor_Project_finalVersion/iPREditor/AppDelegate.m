//
//  AppDelegate.m
//  iPREditor
//
//  Created by admin on 10/28/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "AppDelegate.h"
#import "FileTool.h"
#import "PRTabbarController.h"
#import "SettingViewController.h"
#import "FolderViewController.h"
#import "SSZipArchive.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [NSThread sleepForTimeInterval:1.5];
    self.isChanged = NO;
    self.goToFile = NO;
    self.fileOpened = NO;
    
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    self.documentDirectory = [paths objectAtIndex:0];
    
    NSLog(@"self.documentDirectory: %@", self.documentDirectory);
    
    
    
    self.fileTool = [FileTool instance];
    self.bundlePath = [[NSBundle mainBundle] bundlePath];
    
    //Clear temp directory
    [self.fileTool clearFolder:NSTemporaryDirectory()];
    
    if ([self.fileTool isExist:[self.documentDirectory stringByAppendingPathComponent:@"PrFile/Sample"]] == NO) {
        
        [self.fileTool createDirectory:[self.documentDirectory stringByAppendingPathComponent:@"PrFile"]];
        
        [self.fileTool copyFrom:[self.bundlePath stringByAppendingPathComponent:@"Sample"] to:[self.documentDirectory stringByAppendingPathComponent:@"PrFile/Sample"]];
    }
    
    //Document目录下没有Config目录
    if ([self.fileTool isExist:[self.documentDirectory stringByAppendingPathComponent:@"Config/"]] == NO) {
        
        [SSZipArchive unzipFileAtPath:[self.bundlePath stringByAppendingPathComponent:@"Config.zip"] toDestination:[self.documentDirectory stringByAppendingPathComponent:@"Config/"]];
        
    }
    //已存在Config目录，需要检测是配制文件是否齐全
    else {
        
        [SSZipArchive unzipFileAtPath:[self.bundlePath stringByAppendingPathComponent:@"Config.zip"] toDestination:NSTemporaryDirectory()];
        
        for (NSString* configFile in [self.fileTool listFiles:NSTemporaryDirectory()]) {
            
            //如果不存在在Docuemnt/Config/目录
            if ([self.fileTool isExist:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"Config/%@",configFile]]] == NO) {
                
                [self.fileTool copyFrom:[NSTemporaryDirectory() stringByAppendingPathComponent:configFile] to:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"Config/%@",configFile]]];
            }
            
        }
    }
    [self.fileTool clearFolder:NSTemporaryDirectory()];
    
    if ([self.fileTool isExist:[self.documentDirectory stringByAppendingPathComponent:@"Config/__MACOSX"]]) {
        
        [self.fileTool removeFile:[self.documentDirectory stringByAppendingPathComponent:@"Config/__MACOSX"]];
    }
    
    
    if ([launchOptions objectForKey:@"UIApplicationLaunchOptionsURLKey"]) {
        
        self.fileURL = [launchOptions objectForKey:@"UIApplicationLaunchOptionsURLKey"];
        self.goToFile = YES;
    }
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {

    
}

- (void)applicationDidEnterBackground:(UIApplication *)application {

    
}

- (void)open {
    if (!self.fileTool) {
        
        self.fileTool = [FileTool instance];
    }
    if (!self.documentDirectory) {
        
        NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        self.documentDirectory = [paths objectAtIndex:0];
    }
    if (!self.bundlePath) {
        
        self.bundlePath = [[NSBundle mainBundle] bundlePath];
    }
    if (!self.storyBoard) {
        
        self.storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    }
    //已经打开了文件
    //Inbox不为空，说明是从第三方打开
    if ([self.fileTool isExist:[self.documentDirectory stringByAppendingPathComponent:@"Inbox"]]) {
        
        BOOL hiThere = NO;
        NSString* fileName;
        //Inbox不为空
        NSArray* files = [self.fileTool listFiles:[self.documentDirectory stringByAppendingPathComponent:@"Inbox"]];
        if ([files count] > 0) {
            
            //复制到documents根目录
            for (NSString* file in files) {
                if ([file isEqualToString:@".DS_Store"] == NO) {
                    hiThere = YES;
                    fileName = file;
                    
                    //先删除
                    [self.fileTool removeFile:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",file]]];
                    
                    //后复制
                    [self.fileTool copyFrom:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",@"Inbox",file]] to:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",file]]];
                }
            }
        }
        //删除Inbox目录
        [self.fileTool removeFile:[self.documentDirectory stringByAppendingPathComponent:@"Inbox"]];
        
        //跳转到第三方打开的文件,这个时候是在PRTabbarController
        if (hiThere) {
            
            NSString* path = [self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]];
            
            //this way is passed
            //打开的是zip，需要解压
            if ([[[fileName pathExtension] lowercaseString] isEqualToString:@"zip"]) {
                
                //先考到document目录
                [self.fileTool copyFrom:path to:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]]];
                
                //清空Inbox目录
                [self.fileTool removeFile:[self.documentDirectory stringByAppendingPathComponent:@"Inbox"]];
                
                //创建目录
                [self.fileTool createDirectory:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",[fileName stringByDeletingPathExtension]]]];
                
                //解压
                [SSZipArchive unzipFileAtPath:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]] toDestination:[self.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",[fileName stringByDeletingPathExtension]]]];
                
                FolderViewController* view = [self.storyBoard instantiateViewControllerWithIdentifier:@"story_folderViewController"];

                [view setValue:[fileName stringByDeletingPathExtension] forKey:@"headTitle"];
                [view setValue:[NSString stringWithFormat:@"PrFile/%@",[fileName stringByDeletingPathExtension]] forKey:@"currentPath"];
                
                [self.navi pushViewController:view animated:YES];
            }
            
            //this way is passed
            else {
                
                self.temFilePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.tem",[path lastPathComponent]]];
                
                [[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil] writeToFile:self.temFilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
                
                PRTabbarController* view = [self.storyBoard instantiateViewControllerWithIdentifier:@"story_prTabBar"];
                
                for (int i = 0; i < [[view viewControllers] count]; i++) {

                    [[[[[view viewControllers] objectAtIndex:i] viewControllers] objectAtIndex:0] setValue:path forKey:@"fullPath"];

                }

                [self.navi pushViewController:view animated:YES];
            }
        }
    }
}

- (void)applicationWillEnterForeground:(UIApplication *)application {

    [self open];
    
}

//通过airdrop打开 放入Inbox
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    [self open];
    
    return NO;
}



- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
