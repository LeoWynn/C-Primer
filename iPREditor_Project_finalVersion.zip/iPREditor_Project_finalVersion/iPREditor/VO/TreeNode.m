//
//  TreeNode.m
//  iPREditor
//
//  Created by admin on 11/2/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "TreeNode.h"

@implementation TreeNode


- (id)mutableCopyWithZone:(NSZone *)zone {

    TreeNode* newNode = [[TreeNode allocWithZone:zone] init];
    newNode.nodeLevel = self.nodeLevel;
    newNode.isExpanded = self.isExpanded;
    newNode.keyLabel = self.keyLabel;
    newNode.keyPath = self.keyPath;
    newNode.control = self.control;
    newNode.childNodes = [self.childNodes mutableCopy];
    newNode.toolTip = self.toolTip;

    return newNode;
}


- (id)copyWithZone:(NSZone *)zone {
    
    TreeNode* newNode = [[TreeNode allocWithZone:zone] init];
    
    newNode.nodeLevel = self.nodeLevel;
    newNode.isExpanded = self.isExpanded;
    newNode.keyLabel = self.keyLabel;
    newNode.keyPath = self.keyPath;
    newNode.control = self.control;
    newNode.childNodes = [self.childNodes copy];
    newNode.toolTip = self.toolTip;
    return newNode;
}

@end
