//
//  FileTool.h
//  FileToolTest
//
//  Created by Luke on 10/27/15.
//  Copyright (c) 2015 Luke. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileTool : NSObject

+ (FileTool*)instance;

//创建文件
- (BOOL)createFile: (NSString*) filePath;

//创建目录
- (BOOL)createDirectory: (NSString*) directoryPath;

//枚举目录内容，不会递归枚举
- (NSArray*)listFiles: (NSString*) direcotry;

//读取文件内容
- (NSString*)contentsAtPath: (NSString*) filePath;

//写入文件内容
- (BOOL)write: (NSString*) content at: (NSString*) filePath append: (BOOL) append;

//是否是文件
- (BOOL)isFile: (NSString*) path;

//删除文件或文件夹
- (BOOL)removeFile: (NSString*) path;

//清空文件夹（保留文件夹)
- (void)clearFolder: (NSString*) path;

//获取文件信息
- (NSDictionary*)getAttributes: (NSString*) path;

//重命名或移动文件
- (BOOL)rename: (NSString*) sourceFileName to: (NSString*) targetFileName;

//复制文件或文件夹
- (BOOL)copyFrom: (NSString*) sourcePath to :(NSString*) targetPath;

//文件是否存在
- (BOOL)isExist: (NSString*) path;

//文件类型
/*
 *255216->jpg 7173->gif 6677-bmp 13780->png 6787->swf 7790->exe-dll 8297->rar 8075->zip
 *55122->7z 6063->xml 6033->html 239187->aspx 117115->cs 119105->js 102100->txt 255254->sql
 */
- (NSString*)fileType: (NSString*) path;



@end
