//
//  CustomMessTool.m
//  iPREditor
//
//  Created by admin on 11/13/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "CustomMessTool.h"
#import "TreeNode.h"

@implementation CustomMessTool


+ (NSMutableArray*)getRelation: (NSString*)keyPath withValue: (id)value andProduct: (NSString*)product {
    
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString* documentPath = [paths objectAtIndex:0];
    
    NSString* configFile = [documentPath stringByAppendingPathComponent:@"Config/Relation.plist"];
    
    NSMutableDictionary* dic = [[NSMutableDictionary alloc] initWithContentsOfFile:configFile];
    
    //NSString* keyPath= @"RestoreOptions.ProvisionMesa";
    
    //id value = @"UID";
    //NSString* product = @"N61";
    //id value = [NSNumber numberWithBool:YES];
    
    NSMutableArray* result = [[NSMutableArray alloc] init];
    //NSLog(@"%@",[dic allKeys]);
    
    for (NSString* key in [dic allKeys]) {
        
        //无关单向
        if ([key isEqualToString:@"INDEPENDENT_ONEWAY"]) {
            
            NSDictionary* node = [dic objectForKey:key];
            if ([node objectForKey:keyPath]) {
                
                NSArray* array = [node objectForKey:keyPath];
                
                for (NSDictionary* tem in array) {
                    
                    //得到value数组
                    NSArray* values = [tem objectForKey:@"Values"];
                    
                    //如果存在
                    if ([values containsObject:value]) {
                        
                        //取得key_values
                        NSDictionary* key_valueDic = [tem objectForKey:@"key_values"];
                        
                        for (NSString* relatedKey in [key_valueDic allKeys]) {
                            
                            TreeNode* node = [[TreeNode alloc] init];
                            node.keyPath = relatedKey;
                            node.extra = [key_valueDic objectForKey:relatedKey];
                            [result addObject:node];
                        }
                    }
                }
            }
            
        }
        //无关双向
        else if ([key isEqualToString:@"INDEPENDENT_TWOWAY"]) {
            
            NSArray* array = [dic objectForKey:key];
            
            for (NSDictionary* tem in array) {
                
                //存在key
                if ([tem objectForKey:keyPath]) {
                    
                    NSDictionary* valueGroup = [tem objectForKey:keyPath];
                    NSString* key = nil;
                    //找到value对应的key名
                    for (NSString* valueKey in [valueGroup  allKeys]) {
                        
                        //value是String类型
                        if ([value respondsToSelector:@selector(substringFromIndex:)]) {
                            
                            if ([[valueGroup objectForKey:valueKey] isEqualToString:value]) {
                                key = valueKey;
                                break;
                            }
                        }
                        if ([valueGroup objectForKey:valueKey] == value) {
                            key = valueKey;
                            break;
                        }
                        
                    }
                    //NSLog(@"key:%@",key);
                    if (key) {
                        
                        for (NSString* target in [tem allKeys]) {
                            
                            if ([target isEqualToString:keyPath] == NO) {
                                
                                TreeNode* node = [[TreeNode alloc] init];
                                node.keyPath = target;
                                node.extra = [[tem objectForKey:target] objectForKey:key];
                                [result addObject:node];
                            }
                        }
                    }
                }
            }
        }
        //相关单向
        else if ([key isEqualToString:@"DEPENDENT_ONEWAY"]) {
            
            NSDictionary* topDiction = [dic objectForKey:key];
            if ([topDiction objectForKey:keyPath]) {
                
                NSArray* array = [topDiction objectForKey:keyPath];
                
                for (NSDictionary* tem in array) {
                    
                    //得到Values
                    NSArray* values = [tem objectForKey:@"Values"];
                    
                    NSArray* products = [tem objectForKey:@"Product"];
                    //得到key_values
                    NSDictionary* keyValueDiction = [tem objectForKey:@"key_values"];
                    
                    if ([values containsObject:value] && [products containsObject:product]) {
                        
                        for (NSString* target in [keyValueDiction allKeys]) {
                            
                            TreeNode* node = [[TreeNode alloc] init];
                            node.keyPath = target;
                            node.extra = [keyValueDiction objectForKey:target];
                            [result addObject:node];
                        }
                    }
                }
            }
        }
        
        //相关双向
        else if ([key isEqualToString:@"DEPENDENT_TWOWAY"]){
            
            NSArray* array = [dic objectForKey:key];
            
            for (NSDictionary* tem in array) {
                
                //存在key,且产品符合
                if ([tem objectForKey:keyPath] && [[tem objectForKey:@"Product"] containsObject:product]) {
                    
                    NSDictionary* valueGroup = [tem objectForKey:keyPath];
                    NSString* key = nil;
                    //找到value对应的key名
                    for (NSString* valueKey in [valueGroup  allKeys]) {
                        
                        //value是String类型
                        if ([value respondsToSelector:@selector(substringFromIndex:)]) {
                            
                            if ([[valueGroup objectForKey:valueKey] isEqualToString:value]) {
                                key = valueKey;
                                break;
                            }
                        }
                        if ([valueGroup objectForKey:valueKey] == value) {
                            key = valueKey;
                            break;
                        }
                        
                    }
                    //NSLog(@"key:%@",key);
                    if (key) {
                        
                        for (NSString* target in [tem allKeys]) {
                            
                            if ([target isEqualToString:keyPath] == NO) {
                                
                                TreeNode* node = [[TreeNode alloc] init];
                                node.keyPath = target;
                                node.extra = [[tem objectForKey:target] objectForKey:key];
                                [result addObject:node];
                            }
                        }
                    }
                }
            }
            
        }
        else {
            
        }
    }
    return result;
}


+ (NSString*)getProduct: (NSString*)keyPath inDictionary: (id)dictionary {
    
    id node = dictionary;
    
    for (NSString* str in [keyPath componentsSeparatedByString:@"."]) {
        
        //NSLog(@"%@",str);
        node = [node objectForKey:str];
    }
    return [node description];
}

+ (id)gimmeLastNode: (NSString*)keyPath inDictionary: (id)dictionary {
    
    id node = dictionary;
    
    for (NSString* str in [keyPath componentsSeparatedByString:@"."]) {
        
        //NSLog(@"%@",str);
        node = [node objectForKey:str];
    }
    return node;
}

+ (NSString*)gimmeType: (id)node {
    
    NSString* type;
    
    //Dictionary
    if ([DIC_SET containsObject:[[node class] description]]) {
        
        type = DICTIONARY_STR;
    }
    //Array
    else if ([ARR_SET containsObject:[[node class] description]]) {
        
        type = ARRAY_STR;
    }
    //String
    else if ([STR_SET containsObject:[[node class] description]]) {
        
        type = STRING_STR;
    }
    //Boolean
    else if ([BLN_SET containsObject:[[node class] description]]) {
        
        type = BOOLEAN_STR;
    }
    //Integer
    else if ([NUM_SET containsObject:[[node class] description]]) {
        
        type = INTEGER;
    }
    return type;
}

@end
