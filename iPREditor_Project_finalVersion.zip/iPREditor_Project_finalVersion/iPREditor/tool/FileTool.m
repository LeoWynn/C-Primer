//
//  FileTool.m
//  FileToolTest
//
//  Created by Luke on 10/27/15.
//  Copyright (c) 2015 Luke. All rights reserved.
//

#import "FileTool.h"

@implementation FileTool

static NSFileManager* fileManager = nil;
static FileTool* tool = nil;

- (id)init {
    self = [super init];
    if (self) {
        //[FileTool instance];
    }
    return self;
}

+ (FileTool*)instance {
    
    if(tool == nil) {
        tool = [[FileTool alloc] init];
        fileManager = [NSFileManager defaultManager];
    }
    return tool;
}

//创建文件
- (BOOL)createFile: (NSString*) filePath {
    
    if( [fileManager fileExistsAtPath:filePath ] == NO ) {
        //NSLog(@"%@ not exists",filePath);
        NSString* folder = [filePath stringByDeletingLastPathComponent];
        if ( [fileManager fileExistsAtPath:folder] == NO) {
            //创建文件夹先
            [fileManager createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:NULL];
        }
        //后创建文件
        [fileManager createFileAtPath:filePath contents:NULL attributes:NULL];
    }
    return YES;
}

//创建文件夹
- (BOOL)createDirectory: (NSString*) directoryPath {
    
    //存在
    if( [fileManager fileExistsAtPath:directoryPath ] == YES ) {
        //NSLog(@"%@ directory not exists",directoryPath);
         [fileManager removeItemAtPath:directoryPath error:NULL];
        //return [fileManager createDirectoryAtPath:directoryPath withIntermediateDirectories:YES attributes:nil error:NULL];
    }
    return [fileManager createDirectoryAtPath:directoryPath withIntermediateDirectories:YES attributes:nil error:NULL];
}

//枚举目录内容，不会递归枚举
- (NSArray*)listFiles: (NSString*) direcotry {
    
    NSArray* result = [fileManager contentsOfDirectoryAtPath:direcotry error:NULL];
    return result;
}

//读取文件内容
- (NSString*)contentsAtPath: (NSString*) filePath {
    
    return [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:NULL];
}

//写入文件内容
- (BOOL)write: (NSString*) content at: (NSString*) filePath append: (BOOL) append{
    if ([fileManager fileExistsAtPath:filePath] == NO) {
        [self createFile:filePath];
    }
    NSData* data = [content dataUsingEncoding:NSUTF8StringEncoding];
    NSFileHandle* outFile = [NSFileHandle fileHandleForWritingAtPath:filePath];
    if( append ) {
        [outFile seekToEndOfFile];
    }
    [outFile writeData:data];
    return YES;
}

//判断是否是文件，
- (BOOL)isFile: (NSString*) path {
    
    BOOL isDirectory;
    if ([fileManager fileExistsAtPath:path isDirectory:&isDirectory]) {
        if (isDirectory) {
            return NO;
        }
        return YES;
    }
    return NO;
}

//删除文件或文件夹
- (BOOL)removeFile: (NSString*) path {
    
    if ([fileManager fileExistsAtPath:path] == NO) {
        return NO;
    }
    
    return [fileManager removeItemAtPath:path error:NULL];
}

//清空文件夹（保留文件夹)
- (void)clearFolder: (NSString*) path {
    
    NSArray* files = [self listFiles:path];
    
    for (NSString* file in files) {
        
        [self removeFile:[path stringByAppendingPathComponent:file]];
    }
}

//获取文件信息
- (NSDictionary*)getAttributes: (NSString*) path {
    
    if ([fileManager fileExistsAtPath:path] == NO) {
        
        return NULL;
    }
    return [fileManager attributesOfItemAtPath:path error:NULL];
}

//更改文件名,源文件和目标文件不在同目录，则移动
- (BOOL)rename: (NSString*) sourceFileName to: (NSString*) targetFileName {
    
    if ([fileManager fileExistsAtPath:sourceFileName] == NO || [fileManager fileExistsAtPath:targetFileName] == YES) {

        return NO;
    }
    return [fileManager moveItemAtPath:sourceFileName toPath:targetFileName error:NULL];
}

//复制文件
- (BOOL)copyFrom: (NSString*) sourcePath to :(NSString*) targetPath {
    
    if ([sourcePath isEqualToString:targetPath]) {
        return NO;
    }
    
    if ([self isExist:sourcePath]) {
        
        //文件
        if ([self isFile:sourcePath]) {
            
            return [fileManager copyItemAtPath:sourcePath toPath:targetPath error:NULL];
        }
        //文件夹
        else {
            
            NSMutableArray* files = [[NSMutableArray alloc] init];
            NSDirectoryEnumerator *direnum = [fileManager enumeratorAtPath:sourcePath];
            NSString *filename ;
            while (filename = [direnum nextObject])
            {
                [files addObject:filename];
                
            }
            [self createDirectory:targetPath];
            for (filename in files) {
                
                //文件
                if ([self isFile:[sourcePath stringByAppendingPathComponent:filename]]) {
                    
                    [self copyFrom:[sourcePath stringByAppendingPathComponent:filename] to:[targetPath stringByAppendingPathComponent:filename]];
                }
                //文件夹
                else {
                    [self createDirectory:[targetPath stringByAppendingPathComponent:filename]];
                }
                
            }
            return YES;
        }
    }
    return NO;
}

//路径是否存在
- (BOOL)isExist: (NSString*) path {
    
    return [fileManager fileExistsAtPath:path];
}

//文件类型
/*
 *255216->jpg 7173->gif 6677-bmp 13780->png 6787->swf 7790->exe-dll 8297->rar 8075->zip
 *55122->7z 6063->xml 6033->html 239187->aspx 117115->cs 119105->js 102100->txt 255254->sql
 */
- (NSString*)fileType: (NSString*) path {
    
    NSData* data = [NSData dataWithContentsOfFile:path];
    
    if (data.length<2) {
        
        return  NULL;
    }
    int char1 = 0,char2 = 0;
    
    [data getBytes:&char1 range:NSMakeRange(0, 1)];
    
    [data getBytes:&char2 range:NSMakeRange(1, 1)];
    
    NSString *numStr = [NSString stringWithFormat:@"%i%i",char1,char2];
    
    int num = [numStr intValue];
    
    switch (num) {
        case 8075:
            return @"zip";
        case 7173:
            return @"gif";
        case 6677:
            return @"bmp";
        case 13780:
            return @"png";
        case 6787:
            return @"swf";
        case 7790:
            return @"exe";
        case 8297:
            return @"rar";
        case 55122:
            return @"7z";
        case 6063:
            return @"xml";
        case 6033:
            return @"html";
        case 239187:
            return @"aspx";
        case 117115:
            return @"cs";
        case 119105:
            return @"js";
        case 102100:
            return @"txt";
        case 255254:
            return @"sql";
    }
    return NULL;
}



@end
